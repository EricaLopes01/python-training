# Lab Simple CLI

Este projeto cria uma CLI simples usando Python e o módulo Click.
